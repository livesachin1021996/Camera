#Camera recorder using Java

**Requirements:**

* JDK

* IDE such as Netbeans or Eclipse 

* Javacv jars for here https://github.com/bytedeco/javacv

**Thanks to**

TableLayout team https://github.com/EsotericSoftware/tablelayout for their efforts to make design easier with swing.

**Video of steps**

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/-s9qqVPQngU/0.jpg)](https://www.youtube.com/watch?v=-s9qqVPQngU)


